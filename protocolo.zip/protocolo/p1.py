import random


if __name__ == "__main__":

    long_cadena = 4
    num_palabras = 5
    num_act = 0
    activo = random.randint(0,1)

    
    print(f"El protocolo se ha activado {num_act} veces")
    print("No")